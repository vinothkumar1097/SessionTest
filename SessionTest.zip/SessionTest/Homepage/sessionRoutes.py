from flask import Flask, session, render_template, redirect, url_for, request, abort
from Homepage import app


@app.route('/')
def home():
    if ('log' in session):
        return render_template('Homepage.html')
    return redirect(url_for('login'))

@app.route('/login', methods=['GET', 'POST'])
def login():
    if ('log' in session):
        return redirect(url_for('home'))
    error = ''
    if request.method == 'POST':
        if request.form['username'] == 'admin' and request.form['password'] == 'admin':
            session['log'] = 'User'
            return redirect(url_for('home'))
        else:
            error = 'Invalid Credentials. Please try again.'
            return render_template('Login.html', error=error)
    return render_template('Login.html', error=error)

@app.route('/contact')
def contact():
    if ('log' in session):
        return render_template('Contact.html')
    return redirect(url_for('login'))

@app.route('/logout')
def logout():
    if ('log' in session):
        session.pop('log', None)
    return redirect(url_for('login'))

@app.route('/session')
def getSession():
    return '''
        Log : {0}
        '''.format(session.get('log'))

@app.errorhandler(404)
def error_404(e):
    return render_template('notFound.html'), 404