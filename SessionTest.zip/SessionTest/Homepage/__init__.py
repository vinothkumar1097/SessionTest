from flask import Flask
import os

app = Flask(__name__)
app.config['SECRET_KEY'] = os.urandom(16)

from Homepage import sessionRoutes